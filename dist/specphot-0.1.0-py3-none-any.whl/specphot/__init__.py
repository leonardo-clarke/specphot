from .utils import Spectrum

# Define the public API
__all__ = ["Spectrum"]

# Define the version of the package
__version__ = "0.1.0"